package mindsprint.learnings;
import java.util.*;
public class ArrayListEg {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		ArrayList<String> al=new ArrayList<String>();  
//		System.out.println("Initial size of Arraylist is "+ al.size());  // SIZE OF ARRAYLIST
//		al.add("Hai");
//		al.add("Hello");
//		al.add("Hai");
//		al.add("Come On");
//		al.add("Eat the food");
//		al.add("Take rest");
//		System.out.println("Arraylist is "+al);
//		System.out.println("New size of Arraylist is "+al.size()); // UPDATED SIZE OF ARRAYLIST
//		al.add(1,"How are you");
//		System.out.println("New Arraylist is "+al);
//		System.out.println("New size of Arraylist is "+al.size());
//		System.out.println("element at position 1 is  : "+ al.get(1)); // GET ELEMENT AT POSITION
//		Collections.reverse(al);   //Reversing order of arraylist
//		System.out.println("Reversed arraylist is : "+ al);    // Printing arraylist after reversing
//		al.set(2, "Bye"); //Setting Bye - Bye at position 6 (or) Replacing Hello by Bye at position 2
//        System.out.println("ArrayList after setting/replacing element at position 2 is : " + al);
//        al.remove(2);
//        System.out.println("New Arraylist is "+al);
//        System.out.println(al.indexOf("Hai"));
//
//        al.remove("Hello");
//        System.out.println("New Arraylist is "+al);
//        System.out.println(al.contains("Hello"));      
//        al.remove(1);
//        System.out.println("New Arraylist is "+al);
//        System.out.println(al.subList(2, 4));
//
//	}
//
//	}
	public static void main(String args[]) {
		ArrayList<String> a1 =new ArrayList<String>(); 
		a1.add("Mango");
		a1.add("Apple");
		a1.add("Litchi");
		a1.add("Grapes");
		a1.add("Banana");
		a1.add("Kiwi");
		a1.add("Chandigarh");
		a1.add("Calgary");
		a1.add("Dance");
		a1.add("Writing");
		System.out.println("Arraylist is: " + a1);
		a1.remove("Writing");
		a1.contains("cricket");
		a1.remove("Calgary");
		a1.remove(4);
		System.out.println("Arraylist is: " + a1);
		System.out.println("4th and 5th element is " + a1.get(3) + a1.get(4));
		a1.reversed();
		System.out.println("Arraylist is: " + a1);
		a1.add(3, "kerala");
		a1.add(1, "mango");
		System.out.println("Arraylist is: " + a1);
		System.out.println(a1.subList(2, 5));


		
	}
}
