package mindsprint.learnings;

public class Calculation {
	int addsub(int a, int b) {
		return a+b;
	}
	double add(double c, double d) {
		return c+d;
	}
	float addsub(float a, float b) {
		return b-a;
	}
	double sub(double c, double d) {
		return d-c;
	}
	int multiply(int a, int b) {
		return b * a;
	}
	public void divide(int a, int b) {
		if(b==0) {
			System.out.println("Infinite");
		}
		else {
			System.out.println(a/b);
		}
	}
	void number(int s) {
		if(s/2==0) {
			System.out.println("Number is even");
		}
		else {
			System.out.println("Number is odd");
		}
	}
//	boolean isprime(int t) {
//		if(t<=1) {
//			return false;
//			for()
//		}
//	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculation calc = new Calculation();
		System.out.println("Add1: " + calc.addsub(24,48));
		System.out.println("Add2: " + calc.add(24.60,40.50));
		System.out.println("Sub1: " + calc.addsub(24.6f,48.6f));
		System.out.println("Sub2: " + calc.sub(24.80,48.77));
		System.out.println("Multiply: " + calc.multiply(2,8));
		calc.divide(24,4);
		calc.divide(24,0);
		calc.number(24);
		calc.number(11);



	}

}
