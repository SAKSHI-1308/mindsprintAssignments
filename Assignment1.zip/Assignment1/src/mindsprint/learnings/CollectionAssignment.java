package mindsprint.learnings;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class CollectionAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet hst = new LinkedHashSet();
		hst.add(340 + 13);
		hst.add(true);
		hst.add('S');
		hst.add(13.03f + 24.97f);
		hst.add(300.13 + 290.005);
		
		System.out.println("The hashset 1 is: " + hst);
		System.out.println(hst.contains(5));
		System.out.println(hst.remove('S'));
		System.out.println("The hashset 1 is: " + hst);
		hst.clear();
		System.out.println("The hashset 1 is: " + hst);
	
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("Java");
		ts.add("Python");
		ts.add("C");
		ts.add("C++");
		ts.add("JS");
		ts.add("Sql");
		System.out.println("The treeset is: " + ts);
		System.out.println(ts.remove("Java"));
		System.out.println(ts.remove("C"));
		System.out.println("The treeset is: " + ts);
		ts.add("react");
		ts.add("html");
		ts.add("css");
		System.out.println("The treeset is: " + ts);
		ts.clear();
		System.out.println("The treeset is: " + ts);
		System.out.println(ts.isEmpty());
	}

}
