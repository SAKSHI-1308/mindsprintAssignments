package mindsprint.learnings;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> ll = new LinkedList<String>();
		ll.add("May");
		ll.add("June");
		ll.add("July");
		ll.add("August");
		ll.add("April");
		ll.add("November");
		ll.addLast("December");
		ll.addFirst("January");
		ll.add(1, "March");
		ll.add(1, "Febuary");
		ll.add(8, "September");
		ll.add(9, "October");
		ll.remove("April");
		ll.add(3, "April");
		System.out.println("Months: " + ll);
		System.out.println("Odd months: ");
		for(int i = 0; i<ll.size(); i++) {
			if(i%2 == 0) {
				System.out.print(ll.get(i) + " ");
			}
		}
		System.out.println();
		System.out.println("Even months: ");
		for(int i = 0; i<=12; i++) {
			if(i%2 != 0) {
				System.out.print(ll.get(i) + " ");
			}
		}
		System.out.println();
		Iterator<String> itr=ll.iterator();
        while(itr.hasNext()) {
        System.out.print(itr.next() + " ");
        }
		System.out.println("First month: " + ll.get(0) + " Last month: " + ll.get(11));
		ll.remove(7);
		System.out.println("After removing birthday month: " + ll);
		System.out.println("");
		System.out.println(ll.peekFirst() + " " + ll.peekLast());
		System.out.println("New list: " + ll);
		System.out.println(ll.pollFirst() + " " + ll.pollLast());
		System.out.println("New list: " + ll);
	}

}
