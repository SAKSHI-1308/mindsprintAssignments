package mindsprint.learnings;

class Product{
	int id = 78;
	String name ="Amul";
	public void display() {
		System.out.println("id: " + id);
		System.out.println("name: " + name);
	}
}
	class A extends Product{
	int count = 50;
	String category = "Butter";
	public void display() {
		
	}
}
	class subA extends A{
		int price = 30;
		int total_price = (count*price);
		public void display(){
			System.out.println("id: " + id);
			System.out.println("name: " + name);
			System.out.println("count: " + count);
			System.out.println("category: " + category);
			System.out.println("Total Price: " + total_price);
			}
	}
	class B extends Product{
		int count = 90;
		String category = "Milk";
		public void display() {
			
		}

}
	class subB extends B{
		int price = 10;
		int total_price = (count*price);
		public void display(){
		System.out.println("id: " + id);
		System.out.println("name: " + name);
		System.out.println("count: " + count);
		System.out.println("category: " + category);
		System.out.println("Total Price: " + total_price);
		}
	}
public class Inheritence {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Product pr = new Product();
//		pr.display();
		subA subA = new subA();
		subA.display();
		
		subB subB = new subB();
		subB.display();
//		subB.price();
//		subB.total_price();
		
	}

}
