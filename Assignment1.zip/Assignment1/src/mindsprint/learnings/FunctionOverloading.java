package mindsprint.learnings;

public class FunctionOverloading {
//	public void area(int s,int t){
//		System.out.println("The area is: " + (s+t));
//	}
//	float area(float radius) {
//		float result = 3.14f * radius * radius;
//		return result;
//	}
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		FunctionOverloading func = new FunctionOverloading();
//		float y = func.area(10.5f);
//		System.out.println("The area of circle is: " + y);
//		func.area(13,29);
//
//	}
	//Assignment 2
	public int area(int s,int h) {
		int ans = s*h;
		return ans;
	}
	int carea(int radius) {
		int result = (int) (3.14f *radius*radius);
		return result;
	}
	public static void main(String[] args) {
		FunctionOverloading func = new FunctionOverloading();
		System.out.println("Rhombus area: "+ func.area(10,3));
		System.out.println("Circle area: "+ func.carea(3));
		
	}
}
