package mindsprint.learnings;

import java.util.HashMap;

public class MapAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("1","Canada");
		hm.put("2","India");
		hm.put("3","China");
		hm.put("4","Australia");
		hm.put("5","Austria");
		hm.put("6","Germany");
		hm.put("7","London");
		hm.put("8","Dubai");
		hm.put("9","Africa");
		hm.put("10","America");
		
		for (String key : hm.keySet()) {
            System.out.println(key + ":\t" + hm.get(key));
        }

	

	}

}
