package mindsprint.learnings;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet hs = new HashSet();
		hs.add(340);
		hs.add(true);
		hs.add("Hii");
		hs.add(300.13);
		hs.add(new String("Java"));
		
		System.out.println("The hashset is" + hs);
		System.out.println(hs.contains('H'));
		
//		HashSet<String> hsnew = new HashSet<String>();
//		hsnew.add("India");
//		hsnew.add(new String("Java"));
//		hsnew.add("Sri Lanka");
//		hsnew.add("Europe");
//		hsnew.add("Austriaia");
//		hsnew.add("HTML");
//		hsnew.add("Python");
//		System.out.println(" the hashset is " + hsnew);
//		
//		LinkedHashSet<String> hsnew = new LinkedHashSet<String>();
//		hsnew.add("India");
//		hsnew.add(new String("Java"));
//		hsnew.add("Sri Lanka");
//		hsnew.add("Europe");
//		hsnew.add("Austriaia");
//		hsnew.add("HTML");
//		hsnew.add("Python");
//		System.out.println(" the hashset is " + hsnew);
//		
//		hsnew.addAll(hs);
//		System.out.println("The new hashset is " + hsnew);
//	
		TreeSet<String> hsnew = new TreeSet<String>();
		hsnew.add("India");
		hsnew.add(new String("Java"));
		hsnew.add("Sri Lanka");
		hsnew.add("Europe");
		hsnew.add("Austriaia");
		hsnew.add("HTML");
		hsnew.add("Python");
		System.out.println(" the hashset is " + hsnew);
		
	}

}
